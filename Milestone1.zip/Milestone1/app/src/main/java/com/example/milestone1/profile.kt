package com.example.milestone1

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class profile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile)

        // Retrieve the username from the intent
        val userName = intent.getStringExtra("USERNAME")

        // Find the TextView by its ID
        val nameTextView = findViewById<TextView>(R.id.name)

        // If the username is not null, update the TextView with the user's name
        if (!userName.isNullOrEmpty()) {
            nameTextView.text = userName
        }

        val mapimage = findViewById<ImageView>(R.id.imageinbox2)
        val more = findViewById<ImageView>(R.id.imageinbox8)
        val setting = findViewById<ImageView>(R.id.imageinbox7)
        val tips = findViewById<ImageView>(R.id.imageinbox6)


        mapimage.setOnClickListener {
            val intent = Intent(this, MapActivity::class.java)
            startActivity(intent)
        }

        more.setOnClickListener {
            val intent = Intent(this, save::class.java)
            startActivity(intent)
        }

        setting.setOnClickListener {
            val intent = Intent(this, settings::class.java)
            startActivity(intent)
        }

        tips.setOnClickListener {
            val intent = Intent(this, GoogleMaps::class.java)
            startActivity(intent)
        }
    }
}

